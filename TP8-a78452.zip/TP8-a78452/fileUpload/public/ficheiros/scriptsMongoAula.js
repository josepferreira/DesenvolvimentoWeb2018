db.atletas.find({equipa:/turbulentos/i},{nome:true, dataNasc:true, _id:false}).pretty()
db.atletas.find({equipa:/turbulentos/i},{nome:true, dataNasc:true, _id:false}).count()
db.atletas.insert({nome: "José Pedro", prova:"N SEI"})
