$(document).ready(function () {
    $('#tabela').load('http://localhost:4448/ficheiro')
    $('#myFileForm').submit( function(e) {
        e.preventDefault()
        ajaxPost()
    })

    function ajaxPost(){
        var data = new FormData($('#myFileForm')[0])
        $.ajax({
            type: "POST",
            contentType: false,
            processData: false,
            url: "http://localhost:4448/ficheiro/guardar",
            data: data,
            success: function (nome) {
                alert('Ficheiro ' + nome + ' adicionado com sucesso!')
                var n = $("#ficheiro").val()
                var nomepartido = n.split('\\')
                var nome=nomepartido[2]
                var desc = $("#desc").val()
                var html = '<tr><td><a href=\'/ficheiros/' + nome + '\'>' + nome
                html += '</a></td><td>' + desc + '</td></tr>'
                $('#tabela').append(html)
                $('#ficheiro').val('')
                $('#desc').val('')
            },
            error: e => {
                alert('Erro no post: ' + JSON.stringify(e))
                console.log('Erro no post: ' + JSON.stringify(e))
                $('#ficheiro').val('')
                $('#desc').val('')
            }
        })
        

    }
    
})