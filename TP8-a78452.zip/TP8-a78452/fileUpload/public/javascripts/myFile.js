$(document).ready(function () {
    $('#tabela').load('http://localhost:4448/ficheiro')
    $('#adicionar').click( function(e) {
        e.preventDefault()
        var n = $("#ficheiro").val()
        var nomepartido = n.split('\\')
        var nome=nomepartido[2]
        var desc = $("#desc").val()
        var html = '<tr><td><a href=\'' + nome + '\'>' + nome
        html += '</a></td><td>' + desc + '</td></tr>'
        $('#tabela').append(html)
        ajaxPost()
    })

    function ajaxPost(){
        var data = new FormData($('#myFileForm')[0])
        $.ajax({
            type: "POST",
            contentType: false,//"application/json",
            processData: false,
            url: "http://localhost:4448/ficheiro/guardar",
            data: data,//JSON.stringify({ficheiro: $('#ficheiro'), descricao: $('#desc').val()}),
            //dataType: 'json',
            success: function (nome) {
                alert('merda')
                alert('Ficheiro ' + nome + ' adicionado com sucesso!')
            },
            error: e => {
                alert('Erro no post: ' + e)
                console.log('Erro no post: ' + e)
            }
        })
        $('#ficheiro').val('')
        $('#desc').val('')

    }
    
})