var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var formidable = require('formidable')
var fs = require('fs')



var myBD = __dirname + '/ficheiros.json'

/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index');
})

router.get('/ficheiro', (req,res) => {

  jsonfile.readFile(myBD, (erro, ficheiros) => {
      if(!erro){
        res.render('lista', {lista: ficheiros})
      }
      else{
        res.render('error', {e: erro})
      }
  })

})

router.post('/ficheiro/guardar', (req, res) => {
  var nome = ''
  var form = new formidable.IncomingForm()
  form.parse(req, (erro, fields, files) => {
      if(!erro){ /////
          var fenviado = files.ficheiro.path
          var fnovo = __dirname + '/../public/ficheiros/' + files.ficheiro.name

          console.log("Path: " + fnovo)

          var novoficheiro = {}
          novoficheiro.nome = files.ficheiro.name
          novoficheiro.descricao = fields.descricao
          nome = novoficheiro.nome

          jsonfile.readFile(myBD, (erro, ficheiros) => {
              if(!erro){
                  
                  var indice = ficheiros.findIndex( (elemento) => {
                      elemento.nome == novoficheiro.nome
                  })
                  
                  if(indice == -1) {
                      indice = ficheiros.length
                  }

                  console.log('o indice é: ' + indice)

                  ficheiros[indice] = novoficheiro

                  ficheiros.sort((a,b) => {
                      if(a.nome < b.nome){
                          return -1
                      }

                      if(a.nome > b.nome){
                          return 1
                      }
                      return 0
                  })

                  jsonfile.writeFile(myBD, ficheiros, erro =>{
                      if(erro) {
                          //res.write(pug.renderFile('erro.pug', {e: 'Erro na escrita na BD: ' + erro}))
                      }

                      else {
                          console.log('Registo gravado com sucesso!')
                          fs.rename(fenviado, fnovo, (erro) => {
                              if(!erro){
                                res.send(nome)
                                  //return res.redirect(301,'/')
                              }
      
                              else{
                                  //res.write(pug.renderFile('erro.pug', {e: 'Ocorreram erros no armazenamento do ficheiro: ' + erro}))
                                  //res.end()
                              }
                          })
                      }
                  })

              }
              else{
                  //res.write(pug.renderFile('erro.pug', {e: 'Erro na leitura da BD: ' + erro}))
                  //res.end()
              }
          })
      } /////
      else{
         // res.write(pug.renderFile('erro.pug', {e: erro}))
          //res.end()
      }
  })

  

})


module.exports = router;
