var Compositor = require('../../models/compositor')

//Lista de Compositors
module.exports.listar = () => {
    return Compositor
        .find({},{nome:true,dataNasc:true})
        .sort({_id: 1})
        .exec()
}

//Devolve a informacao de um Compositor
module.exports.consultar = cid => {
    return Compositor
        .findOne({_id: cid})
        .exec()
}

//Lista os Compositors do perido P
module.exports.listarPeriodo = periodo => {
    return Compositor
        .find({periodo:periodo},{nome:true,dataNasc:true})
        .sort({_id: 1})
        .exec()
}


//Lista os Compositors do periodo P nascidos depois de D
module.exports.listarPeriodoNascido = (per,nasc) => {
    //console.log(nasc)
    //console.log(per)
    return Compositor
        .where('dataNasc').gte(nasc)
        .where('periodo',per)//,{nome:true,dataNasc:true})
        .select('nome dataNasc')
        .sort({_id: 1})
        .exec()
}