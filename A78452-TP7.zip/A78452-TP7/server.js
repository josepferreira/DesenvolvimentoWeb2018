var express = require('express')
var http = require('http')
var pug = require('pug')
var fs = require('fs')
var formidable = require('formidable')
var logger = require('morgan')
var jsonfile = require('jsonfile')

var myBD = 'ficheiros.json'

var app = express()

app.use(logger('combined'))

app.get('/', (req, res) => {
    res.writeHead(200, {'Content-type': 'text/html; charset=utf-8'})
    console.log('Entrei no /!')
    headersSet = false
    jsonfile.readFile(myBD, (erro, ficheiros) => {
        if(!erro){
            res.write(pug.renderFile('index.pug', 
                        {ficheiros: ficheiros}))
            res.end()
        }
        else{
            res.write(pug.renderFile('erro.pug', {e: 'Erro na leitura da BD: ' + erro}))
            res.end()
 
        }
    })
})

app.get('/w3.css', (req, res) => {
    console.log('Entrei no css!')
    res.writeHead(200, {'Content-Type': 'text/css'})
    fs.readFile('estilo/w3.css', (erro, dados) => {
        if(!erro) res.write(dados)

        else res.write(pug.renderFile('erro.pug', {e: erro}))


        res.end()
    })
})

app.get('/ficheiro/:nome', (req,res) => {
    
    var options = {
        root: __dirname,
        dotfiles: 'deny',
        headers: {
            'x-timestamp': Date.now(),
            'x-sent': true
        }
    }
    var fileName = '/ficheiros/' + req.params.nome
    res.sendFile(fileName,options,function (erro) {
        if (erro) {
            res.write(pug.renderFile('erro.pug', {e: erro}))
        } 
        else {
            console.log('Sent:', fileName)
        }
        res.end()
    })
    
})

  

app.post('/processaForm', (req, res) => {
    console.log('Entrei no processaForm!')
    var form = new formidable.IncomingForm()
    form.parse(req, (erro, fields, files) => {
        if(!erro){ /////
            var fenviado = files.ficheiro.path
            var fnovo = 'ficheiros/' + files.ficheiro.name

            var novoficheiro = {}
            novoficheiro.nome = files.ficheiro.name
            novoficheiro.descricao = fields.descricao

            jsonfile.readFile(myBD, (erro, ficheiros) => {
                if(!erro){
                    
                    var indice = ficheiros.findIndex( (elemento) => {
                        elemento.nome == novoficheiro.nome
                    })
                    
                    if(indice == -1) {
                        indice = ficheiros.length
                    }

                    console.log('o indice é: ' + indice)

                    ficheiros[indice] = novoficheiro

                    ficheiros.sort((a,b) => {
                        if(a.nome < b.nome){
                            return -1
                        }

                        if(a.nome > b.nome){
                            return 1
                        }
                        return 0
                    })

                    jsonfile.writeFile(myBD, ficheiros, erro =>{
                        if(erro) {
                            res.write(pug.renderFile('erro.pug', {e: 'Erro na escrita na BD: ' + erro}))
                        }

                        else {
                            console.log('Registo gravado com sucesso!')
                            fs.rename(fenviado, fnovo, (erro) => {
                                if(!erro){
                                    return res.redirect(301,'/')
                                }
        
                                else{
                                    res.write(pug.renderFile('erro.pug', {e: 'Ocorreram erros no armazenamento do ficheiro: ' + erro}))
                                    res.end()
                                }
                            })
                        }
                    })

                }
                else{
                    res.write(pug.renderFile('erro.pug', {e: 'Erro na leitura da BD: ' + erro}))
                    res.end()
                }
            })
        } /////
        else{
            res.write(pug.renderFile('erro.pug', {e: erro}))
            res.end()
        }
    })
})

app.all('*', (req, res) => {
    console.log('All: ' + req.url)
    return res.redirect(301, '/')

})

var myServer = http.createServer(app)

myServer.listen(4447, () => {
    console.log('Servidor à escuta na porta 4447...')
})