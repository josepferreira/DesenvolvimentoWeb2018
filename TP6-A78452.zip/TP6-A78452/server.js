var http = require('http')
var url = require('url')
var pug = require('pug')
var fs = require('fs')
var jsonfile = require('jsonfile')

var myBD = 'tarefas.json'

var {parse} = require('querystring')

var myServer = http.createServer( (req, res) => {
    var purl = url.parse(req.url, true)
    var query = purl.query

    if(req.method == 'GET'){
        if(purl.pathname == '/' || purl.pathname == '/index'){
            jsonfile.readFile(myBD, (erro, tarefas) => {
                if(!erro){
                    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                    res.write(pug.renderFile('index.pug', {lista: tarefas}))
                    res.end()
                }
                else{
                    res.writeHead(200, {'Content-Type': 'text/css'})
                    res.write(pug.renderFile('erro.pug', {e: 'Erro na leitura da BD: ' + erro}))
                    res.end()
                }
            })
        }

        else if(purl.pathname == '/registo'){
            var today = new Date()
            var dd = today.getDate()
            var mm = today.getMonth()+1
            var yyyy = today.getFullYear()
            today = yyyy + '-' + mm + '-' + dd
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('registo.pug', {diaDeHoje: today}))
            res.end()
        }
        else if(purl.pathname == '/registaTarefa'){
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('tarefa.pug', {aluno: query}))
            res.end()
        }

        else if(purl.pathname == '/lista'){
            
        }
    
        else if(purl.pathname == '/w3.css'){
            res.writeHead(200, {'Content-Type': 'text/css'})
            fs.readFile('estilo/w3.css', (erro, dados) => {
                if(!erro) res.write(dados)

                else res.write(pug.renderFile('erro.pug', {e: erro}))


                res.end()
            })
        }
    
        else{
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
            res.end()
        }
    }

    else if(req.method == 'POST'){
        if(purl.pathname == '/registaTarefa'){
            recuperaInfo(req, 0, resultado => {
                jsonfile .readFile(myBD, (erro, tarefas) => {
                    if(!erro){
                        resultado.id = tarefas.length+1
                        tarefas.push(resultado)
                        //console.dir(tarefas)
                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            if(erro) console.log('Erro na escrita da BD: ' + erro)

                            else console.log('Registo gravado com sucesso!')
                        })
                    }
                })
                //console.log('Info recebida: ' + JSON.stringify(resultado))
                res.end(pug.renderFile('tarefa.pug', {tarefa: resultado}))
            })
        }

        else if(purl.pathname == '/apagar'){
            
            recuperaInfo(req, 1, resultado => {
                jsonfile .readFile(myBD, (erro, tarefas) => {
                    if(!erro){
                        tarefas[JSON.parse(resultado.tarefa)-1].inativa='T'
    
                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            //console.dir(tarefas)
                            if(erro) {
                                console.log('Erro na escrita da BD: ' + erro)
                            }
    
                            else {
                                res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                                res.end(pug.renderFile('tarefa-apagada.pug'))
                                console.log('Tarefa apagada com sucesso!')
                            }
    
                            
                        })
                    }
                })
                
            })
        
        }

        else{
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
            res.end()
        }
    }

    else{
        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
        res.write(pug.renderFile('erro.pug', {e: "Método: " + req.method + " não suportado!"}))
        res.end()
    }
})

myServer.listen(4446, () => {
    console.log('Servidor à escuta na porta 4446...')
})

function recuperaInfo(request, aux, callback){
        if(request.headers['content-type'] == 'application/x-www-form-urlencoded'){
            let body = ''
            if(aux == 0){
                var today = new Date()
                var dd = today.getDate()
                var mm = today.getMonth()+1
                var yyyy = today.getFullYear()
                today = yyyy + '-' + mm + '-' + dd

                body = 'data_registo=' + today + '&'
            }

            request.on('data',bloco => {
                body += bloco.toString()
            })

            request.on('end',() => {
                callback(parse(body))
            })
        }

        else callback(null)
}