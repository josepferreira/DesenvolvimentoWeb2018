var express = require('express');
var router = express.Router();
var axios = require('axios')

/* GET home page. */
router.get('/', function(req, res, next) {
  //vai busccar as classes de nivel 1 e apresenta
  console.log('cheguei')
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
  .then(dados => {
    console.log(dados.data)
    res.render('index', { docs: dados.data });
  })
  .catch(erro => {
      console.log(erro)
      res.render('error',{error: erro,message:'Erro na pesquisa pela classe de nível 1'})
  })
});

router.get('/favicon.ico', (req, res) => {

})

router.get('/:cid', function(req, res, next) {
  /*console.log('Cheguei aqui')
  console.log(req.params.cid)
  console.log('Passei')
  */
  let informacoes
  //vai busccar sa informacoes desta classe de nivel 2 e os seus descendentes e apresenta
  if(req.params.cid != 'favicon.ico'){
    axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.cid)
    .then(dados => {
      informacoes = dados.data
    //console.log(dados)
    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.params.cid + '/descendencia')
    .then(dadosAux => {
      if(informacoes.length > 0){
        informacoes = informacoes[0]
      
        //console.log(informacoes)
        //console.log(dadosAux.data)
        res.render('documento', { info: informacoes, docs: dadosAux.data });
      }
      else{
        let myerro = 'Erro, o documento não existe ou não tem informações'
        res.render('error',{error: myerro,message:'Erro na pesquisa por um documento'})
      }
    })
    .catch(erro => {
        console.log(erro)
        res.render('error',{error: erro,message:'Erro na pesquisa pelos filhos de um documento'})
    })
  })
  .catch(erro => {
      console.log(erro)
      res.render('error',{error: erro,message:'Erro na pesquisa de um documento'})
  })
}
});



module.exports = router;
