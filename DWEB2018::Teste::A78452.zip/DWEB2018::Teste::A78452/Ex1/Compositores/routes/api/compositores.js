var express = require('express')
var router = express.Router()
var Evento = require('../../controllers/api/compositor')

//API para para os eventos

router.get('/', (req,res) => {
    if(req.query.periodo != undefined){
        if(req.query.data != undefined){
            //console.log('Com data: ' + JSON.stringify(req.query.data))
            Evento.listarPeriodoNascido(req.query.periodo,req.query.data)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).jsonp('Erro na listagem de eventos: ' + JSON.stringify(erro)))
        }
        else{
            Evento.listarPeriodo(req.query.periodo)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).jsonp('Erro na listagem de eventos: ' + JSON.stringify(erro)))
        }
    }
    else{
        Evento.listar()
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).jsonp('Erro na listagem de eventos: ' + JSON.stringify(erro)))
    }
})


router.get('/:cid', (req,res) => {    
    Evento.consultar(req.params.cid)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).jsonp('Erro na listagem de eventos: ' + JSON.stringify(erro)))  
})

module.exports = router
